﻿CREATE TABLE [dbo].[student](
	[RecordID] [int] IDENTITY(1,1) PRIMARY KEY NOT NULL,
	[RollNo] [int] NULL,
	[FirstName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[HomeAdd] [nvarchar](150) NULL,
);