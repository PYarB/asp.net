﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    SqlConnection con = new SqlConnection("Data Source=.\\sqldb;database=test;integrated security=true");


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string query = "insert into student output inserted.* values (@RollNo,@FirstName,@LastName,@HomeAdd)";
        SqlDataAdapter adp = new SqlDataAdapter(query, con);
        adp.SelectCommand.CommandType = CommandType.Text;
        adp.SelectCommand.Parameters.AddWithValue("@RollNo", txtRollNo.Text);
        adp.SelectCommand.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
        adp.SelectCommand.Parameters.AddWithValue("@LastName", txtLastName.Text);
        adp.SelectCommand.Parameters.AddWithValue("@HomeAdd", txtHomeAdd.Text);
        DataSet ds = new DataSet();
        try
        {
            adp.Fill(ds);
            lblRecordID.Text = ds.Tables[0].Rows[0]["RecordID"].ToString();
            lblRollNo.Text = ds.Tables[0].Rows[0]["RollNo"].ToString();
            lblFirstName.Text = ds.Tables[0].Rows[0]["FirstName"].ToString();
            lblLastName.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
            lblHomeAdd.Text = ds.Tables[0].Rows[0]["HomeAdd"].ToString();            
            txtFirstName.Text = "";
            txtHomeAdd.Text = "";
            txtLastName.Text = "";
            txtRollNo.Text = "";
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            con.Dispose();
            adp.Dispose();
            ds.Dispose();
        }
    }
}