﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData();
        }
    }
    SqlConnection con = new SqlConnection("Data Source=.\\sqldb;database=test;integrated security=true");


    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string query = "delete from student output deleted.*  where RecordID=@RecordID";
        SqlDataAdapter adp = new SqlDataAdapter(query, con);
        adp.SelectCommand.CommandType = CommandType.Text;
        adp.SelectCommand.Parameters.AddWithValue("@RecordID", txtRollNo.Text);
        DataSet ds = new DataSet();
        try
        {
            adp.Fill(ds);
            lblRecordID.Text = ds.Tables[0].Rows[0]["RecordID"].ToString();
            lblRollNo.Text = ds.Tables[0].Rows[0]["RollNo"].ToString();
            lblFirstName.Text = ds.Tables[0].Rows[0]["FirstName"].ToString();
            lblLastName.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
            lblHomeAdd.Text = ds.Tables[0].Rows[0]["HomeAdd"].ToString();
            txtRollNo.Text = "";
            BindData();
        }
        catch (Exception)
        {
            throw;
        }
        finally
        {
            con.Dispose();
            adp.Dispose();
            ds.Dispose();
        }
    }

    void BindData()
    {
        SqlDataAdapter adp = new SqlDataAdapter("Select * from Student", con);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds.Tables[0].DefaultView;
        GridView1.DataBind();
    }
}